# 1.3.2
- 修复部分安卓手机自动播放音乐，无法获取权限造成卡死问题

# 1.3.1
- 更改为 es module 代码组织

# 1.3.0
- 增加从头播放功能 replay() 方法
- vue 插件安装组件 beta

# 1.2.2
- 按照规范初始化版本号
- PC 获取操作权限提前，添加 waitUntilPlay / waitUntilPause 方法
- 补充调用 play() + setTimeout 的解决方案（暂时注释掉）

# 1.1.2 / 2018-01-11
- 改为 promise 实现授权

# 1.0.2 / 2018-01-08
- first commit